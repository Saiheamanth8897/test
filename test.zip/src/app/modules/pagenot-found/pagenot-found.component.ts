import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagenot-found',
  templateUrl: './pagenot-found.component.html',
  styleUrls: ['./pagenot-found.component.scss']
})
export class PagenotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
