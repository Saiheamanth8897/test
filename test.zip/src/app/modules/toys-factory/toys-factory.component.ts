import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toys-factory',
  templateUrl: './toys-factory.component.html',
  styleUrls: ['./toys-factory.component.scss']
})
export class ToysFactoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
