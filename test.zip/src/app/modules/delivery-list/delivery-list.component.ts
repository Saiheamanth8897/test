import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-list',
  templateUrl: './delivery-list.component.html',
  styleUrls: ['./delivery-list.component.scss']
})
export class DeliveryListComponent implements OnInit {
  p: number = 1;
deliveryList = [{
  "first_name": "Tamma",
  "last_name": "Dubble",
  "wishes": "complexity",
  "Address": "1 Rowland Street"
}, {
  "first_name": "Mitchell",
  "last_name": "Ashwell",
  "wishes": "hybrid",
  "Address": "46 Elmside Alley"
}, {
  "first_name": "Chev",
  "last_name": "Ingerith",
  "wishes": "Fundamental",
  "Address": "8 Alpine Point"
}, {
  "first_name": "Vallie",
  "last_name": "Gainor",
  "wishes": "middleware",
  "Address": "3067 Bay Terrace"
}, {
  "first_name": "Gwendolen",
  "last_name": "Skeath",
  "wishes": "Business-focused",
  "Address": "86 Morrow Street"
}, {
  "first_name": "Rosemary",
  "last_name": "Bruyns",
  "wishes": "scalable",
  "Address": "692 8th Trail"
}, {
  "first_name": "Dalston",
  "last_name": "Boone",
  "wishes": "Advanced",
  "Address": "6 Katie Court"
}, {
  "first_name": "Tatiania",
  "last_name": "Beasley",
  "wishes": "core",
  "Address": "8157 Straubel Center"
}, {
  "first_name": "Franz",
  "last_name": "Chopin",
  "wishes": "analyzing",
  "Address": "238 High Crossing Hill"
}, {
  "first_name": "Korry",
  "last_name": "Lindemann",
  "wishes": "extranet",
  "Address": "57 Pennsylvania Drive"
}, {
  "first_name": "Elliot",
  "last_name": "Meek",
  "wishes": "internet solution",
  "Address": "3617 Comanche Place"
}, {
  "first_name": "Redford",
  "last_name": "Schermick",
  "wishes": "fault-tolerant",
  "Address": "72 Tennyson Terrace"
}, {
  "first_name": "Mark",
  "last_name": "Van de Castele",
  "wishes": "migration",
  "Address": "0 Linden Way"
}, {
  "first_name": "Daniele",
  "last_name": "Canto",
  "wishes": "system-worthy",
  "Address": "667 Riverside Junction"
}, {
  "first_name": "Florrie",
  "last_name": "Fackrell",
  "wishes": "24 hour",
  "Address": "0775 Kenwood Point"
}, {
  "first_name": "Marcille",
  "last_name": "Jeacop",
  "wishes": "Grass-roots",
  "Address": "4815 Jenifer Plaza"
}, {
  "first_name": "Hazel",
  "last_name": "Muneely",
  "wishes": "website",
  "Address": "5597 Surrey Hill"
}, {
  "first_name": "Baily",
  "last_name": "Hallows",
  "wishes": "optimizing",
  "Address": "8130 Warbler Point"
}, {
  "first_name": "Karola",
  "last_name": "Stedell",
  "wishes": "Public-key",
  "Address": "7 Karstens Terrace"
}, {
  "first_name": "Sarette",
  "last_name": "Minifie",
  "wishes": "knowledge user",
  "Address": "88397 Ridgeway Way"
}, {
  "first_name": "Jacky",
  "last_name": "Glazer",
  "wishes": "Expanded",
  "Address": "4 Buhler Way"
}, {
  "first_name": "Adelina",
  "last_name": "Vautrey",
  "wishes": "data-warehouse",
  "Address": "4237 Maryland Center"
}, {
  "first_name": "Charlena",
  "last_name": "Abercromby",
  "wishes": "knowledge base",
  "Address": "92 Evergreen Junction"
}, {
  "first_name": "Kaspar",
  "last_name": "Coombes",
  "wishes": "policy",
  "Address": "3088 High Crossing Terrace"
}, {
  "first_name": "Mareah",
  "last_name": "Lyptratt",
  "wishes": "exuding",
  "Address": "11329 Graceland Parkway"
}, {
  "first_name": "Winn",
  "last_name": "Faveryear",
  "wishes": "4th generation",
  "Address": "35 Annamark Street"
}, {
  "first_name": "Nissa",
  "last_name": "Townrow",
  "wishes": "zero defect",
  "Address": "34116 Artisan Lane"
}, {
  "first_name": "Waverly",
  "last_name": "Christofides",
  "wishes": "superstructure",
  "Address": "31 Maple Wood Place"
}, {
  "first_name": "Zola",
  "last_name": "Bentham",
  "wishes": "moratorium",
  "Address": "52 Glacier Hill Lane"
}, {
  "first_name": "Auria",
  "last_name": "Woollhead",
  "wishes": "web-enabled",
  "Address": "7 Lunder Terrace"
}, {
  "first_name": "Rosemary",
  "last_name": "Durnell",
  "wishes": "frame",
  "Address": "3 Dawn Street"
}, {
  "first_name": "Natal",
  "last_name": "Raoux",
  "wishes": "process improvement",
  "Address": "6232 Meadow Valley Junction"
}, {
  "first_name": "Geralda",
  "last_name": "Navan",
  "wishes": "definition",
  "Address": "92 Brickson Park Way"
}, {
  "first_name": "Sallie",
  "last_name": "Wyrill",
  "wishes": "upward-trending",
  "Address": "84176 Emmet Place"
}, {
  "first_name": "Krista",
  "last_name": "Chinery",
  "wishes": "attitude",
  "Address": "5 Sutherland Plaza"
}, {
  "first_name": "Karlotte",
  "last_name": "Goldring",
  "wishes": "Mandatory",
  "Address": "316 Briar Crest Park"
}, {
  "first_name": "Ferris",
  "last_name": "Blann",
  "wishes": "process improvement",
  "Address": "092 Emmet Street"
}, {
  "first_name": "Bekki",
  "last_name": "Grimsdike",
  "wishes": "extranet",
  "Address": "51660 Eliot Terrace"
}, {
  "first_name": "Rollie",
  "last_name": "Poplee",
  "wishes": "Inverse",
  "Address": "2053 Autumn Leaf Court"
}, {
  "first_name": "Andie",
  "last_name": "Quadrio",
  "wishes": "dynamic",
  "Address": "37 Nancy Park"
}, {
  "first_name": "Merrile",
  "last_name": "Giorgetti",
  "wishes": "concept",
  "Address": "92553 Atwood Alley"
}, {
  "first_name": "Brandais",
  "last_name": "Peche",
  "wishes": "hardware",
  "Address": "1202 Blue Bill Park Park"
}, {
  "first_name": "Craggy",
  "last_name": "Falkingham",
  "wishes": "bottom-line",
  "Address": "146 Forster Plaza"
}, {
  "first_name": "Gustavo",
  "last_name": "Tomaszewicz",
  "wishes": "global",
  "Address": "78955 Vahlen Street"
}, {
  "first_name": "Loraine",
  "last_name": "Mushet",
  "wishes": "Exclusive",
  "Address": "7327 Center Court"
}, {
  "first_name": "Jesselyn",
  "last_name": "King",
  "wishes": "protocol",
  "Address": "20 Mendota Terrace"
}, {
  "first_name": "Cinnamon",
  "last_name": "Graeser",
  "wishes": "productivity",
  "Address": "96 Garrison Terrace"
}, {
  "first_name": "Ernesta",
  "last_name": "Maylott",
  "wishes": "directional",
  "Address": "88872 Eggendart Terrace"
}, {
  "first_name": "Rock",
  "last_name": "Blowin",
  "wishes": "maximized",
  "Address": "5037 Amoth Circle"
}, {
  "first_name": "Patricia",
  "last_name": "Perceval",
  "wishes": "logistical",
  "Address": "8937 Fulton Plaza"
}, {
  "first_name": "Alikee",
  "last_name": "Eborall",
  "wishes": "Visionary",
  "Address": "0302 Lerdahl Terrace"
}, {
  "first_name": "Freddie",
  "last_name": "Raisbeck",
  "wishes": "methodical",
  "Address": "888 Lakeland Drive"
}, {
  "first_name": "Cherrita",
  "last_name": "Iddison",
  "wishes": "product",
  "Address": "15 Magdeline Parkway"
}, {
  "first_name": "Hurley",
  "last_name": "Knath",
  "wishes": "model",
  "Address": "9 Nelson Terrace"
}, {
  "first_name": "Bevin",
  "last_name": "Shelley",
  "wishes": "Expanded",
  "Address": "2 Trailsway Parkway"
}, {
  "first_name": "Filia",
  "last_name": "Firebrace",
  "wishes": "Phased",
  "Address": "0 Bowman Park"
}, {
  "first_name": "Ban",
  "last_name": "Matthessen",
  "wishes": "zero tolerance",
  "Address": "9964 Derek Hill"
}, {
  "first_name": "Hardy",
  "last_name": "Benza",
  "wishes": "array",
  "Address": "23879 Oak Center"
}, {
  "first_name": "Eva",
  "last_name": "Kissick",
  "wishes": "Future-proofed",
  "Address": "54 Service Park"
}, {
  "first_name": "Simone",
  "last_name": "Belamy",
  "wishes": "project",
  "Address": "0 Mallard Park"
}, {
  "first_name": "Ludvig",
  "last_name": "Sherston",
  "wishes": "local",
  "Address": "70 Fairview Drive"
}, {
  "first_name": "Di",
  "last_name": "Elkin",
  "wishes": "maximized",
  "Address": "10 Lindbergh Circle"
}, {
  "first_name": "Gunar",
  "last_name": "Shovelin",
  "wishes": "Devolved",
  "Address": "6 Glacier Hill Street"
}, {
  "first_name": "Marylynne",
  "last_name": "Ventris",
  "wishes": "Balanced",
  "Address": "3 Judy Center"
}, {
  "first_name": "Brooks",
  "last_name": "Osburn",
  "wishes": "access",
  "Address": "0 Sherman Park"
}, {
  "first_name": "Midge",
  "last_name": "Shropsheir",
  "wishes": "Diverse",
  "Address": "647 Melrose Lane"
}, {
  "first_name": "Sherye",
  "last_name": "Aglione",
  "wishes": "leverage",
  "Address": "5 Pleasure Plaza"
}, {
  "first_name": "Alphonso",
  "last_name": "Jobern",
  "wishes": "product",
  "Address": "1808 Dayton Crossing"
}, {
  "first_name": "Huntlee",
  "last_name": "Nosworthy",
  "wishes": "cohesive",
  "Address": "9719 Gateway Point"
}, {
  "first_name": "Ardeen",
  "last_name": "Shortan",
  "wishes": "Fundamental",
  "Address": "92 Clyde Gallagher Trail"
}, {
  "first_name": "Kasper",
  "last_name": "Bolletti",
  "wishes": "reciprocal",
  "Address": "12122 Huxley Parkway"
}, {
  "first_name": "Clark",
  "last_name": "Magwood",
  "wishes": "adapter",
  "Address": "87429 Canary Place"
}, {
  "first_name": "Cordie",
  "last_name": "Robroe",
  "wishes": "conglomeration",
  "Address": "0825 Village Green Avenue"
}, {
  "first_name": "Charla",
  "last_name": "Yerrill",
  "wishes": "real-time",
  "Address": "2454 Florence Junction"
}, {
  "first_name": "Clevey",
  "last_name": "Bangiard",
  "wishes": "system engine",
  "Address": "099 Southridge Road"
}, {
  "first_name": "Kendra",
  "last_name": "Jiggle",
  "wishes": "archive",
  "Address": "2515 Northfield Center"
}, {
  "first_name": "Augustine",
  "last_name": "Hauck",
  "wishes": "bi-directional",
  "Address": "796 Sunbrook Parkway"
}, {
  "first_name": "Trevor",
  "last_name": "Joe",
  "wishes": "synergy",
  "Address": "4784 Rutledge Parkway"
}, {
  "first_name": "Nicola",
  "last_name": "Durand",
  "wishes": "adapter",
  "Address": "388 Scott Park"
}, {
  "first_name": "Harcourt",
  "last_name": "Westmarland",
  "wishes": "modular",
  "Address": "0212 Morning Lane"
}, {
  "first_name": "Javier",
  "last_name": "Valenti",
  "wishes": "Compatible",
  "Address": "52417 Hoffman Trail"
}, {
  "first_name": "Zorana",
  "last_name": "Walters",
  "wishes": "Distributed",
  "Address": "690 Gulseth Circle"
}, {
  "first_name": "Damien",
  "last_name": "Collman",
  "wishes": "superstructure",
  "Address": "27311 Mendota Terrace"
}, {
  "first_name": "Kerr",
  "last_name": "Bothe",
  "wishes": "artificial intelligence",
  "Address": "92 Pond Road"
}, {
  "first_name": "Erie",
  "last_name": "Syde",
  "wishes": "Vision-oriented",
  "Address": "53570 Grover Drive"
}, {
  "first_name": "Miguela",
  "last_name": "Feeley",
  "wishes": "demand-driven",
  "Address": "1 Kings Lane"
}, {
  "first_name": "Dacie",
  "last_name": "Olenov",
  "wishes": "interface",
  "Address": "89 Golf View Plaza"
}, {
  "first_name": "Ellsworth",
  "last_name": "Legrand",
  "wishes": "protocol",
  "Address": "49 Colorado Avenue"
}, {
  "first_name": "Randi",
  "last_name": "Berger",
  "wishes": "regional",
  "Address": "11280 Elmside Hill"
}, {
  "first_name": "Euell",
  "last_name": "Eymor",
  "wishes": "Vision-oriented",
  "Address": "6 Everett Lane"
}, {
  "first_name": "Bernard",
  "last_name": "Joselson",
  "wishes": "solution-oriented",
  "Address": "46 Kensington Point"
}, {
  "first_name": "Gunar",
  "last_name": "Alvarado",
  "wishes": "Virtual",
  "Address": "586 Valley Edge Plaza"
}, {
  "first_name": "Glory",
  "last_name": "Jerrard",
  "wishes": "contingency",
  "Address": "7881 Heffernan Lane"
}, {
  "first_name": "Darelle",
  "last_name": "Dukesbury",
  "wishes": "installation",
  "Address": "8787 David Road"
}, {
  "first_name": "Frazier",
  "last_name": "Yegorchenkov",
  "wishes": "support",
  "Address": "18863 Transport Park"
}, {
  "first_name": "Maud",
  "last_name": "Conan",
  "wishes": "Stand-alone",
  "Address": "89 Kropf Street"
}, {
  "first_name": "Lothario",
  "last_name": "Diggles",
  "wishes": "Multi-tiered",
  "Address": "0 Jenna Park"
}, {
  "first_name": "Aridatha",
  "last_name": "Tennock",
  "wishes": "initiative",
  "Address": "23 Bartillon Circle"
}, {
  "first_name": "Kenneth",
  "last_name": "Slesser",
  "wishes": "tertiary",
  "Address": "45169 Kim Court"
}, {
  "first_name": "Jaclyn",
  "last_name": "Grasha",
  "wishes": "context-sensitive",
  "Address": "25149 8th Parkway"
}]
  constructor() { }

  ngOnInit(): void {
  }

}
