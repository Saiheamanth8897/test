import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DeliveryListComponent } from './modules/delivery-list/delivery-list.component';
import { ToysFactoryComponent } from './modules/toys-factory/toys-factory.component';
import { LegalComponent } from './modules/legal/legal.component';
import { PagenotFoundComponent } from './modules/pagenot-found/pagenot-found.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { TopNavComponent } from './top-nav/top-nav.component';
import {NgxPaginationModule} from 'ngx-pagination';
@NgModule({
  declarations: [
    AppComponent,
    DeliveryListComponent,
    ToysFactoryComponent,
    LegalComponent,
    PagenotFoundComponent,
    SideNavComponent,
    TopNavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
