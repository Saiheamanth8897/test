import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeliveryListComponent } from './modules/delivery-list/delivery-list.component';
import { PagenotFoundComponent } from './modules/pagenot-found/pagenot-found.component';

const routes: Routes = [
  { path: '', component: DeliveryListComponent },
  { path: '**', component: PagenotFoundComponent }, 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
